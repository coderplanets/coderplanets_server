defmodule Timex.Gettext do
  use Gettext, otp_app: :timex, priv: "priv/translations"
end
