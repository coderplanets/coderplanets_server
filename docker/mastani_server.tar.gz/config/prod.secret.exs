use Mix.Config

# In this file, we keep production configuration that
# you'll likely want to automate and keep away from
# your version control system.
#
# You should document the content of this
# file or create a script for recreating it, since it's
# kept out of version control and might be hard to recover
# or recreate for your teammates (or yourself later on).
config :mastani_server, MastaniServerWeb.Endpoint,
  secret_key_base: "xMmROHgjpS1m4KRSVlU+gzT/q/6LSL6KYuof7KxyWSv5B5Am+ozt2oN0amm3wqWF"

# Configure your database
config :mastani_server, MastaniServer.Repo,
  adapter: Ecto.Adapters.Postgres,
  username: "postgres",
  password: "postgres",
  database: "mastani_server_prod",
  pool_size: 15
