use Mix.Config

# In this file, we keep production configuration that
# you'll likely want to automate and keep away from
# your version control system.
#
# You should document the content of this
# file or create a script for recreating it, since it's
# kept out of version control and might be hard to recover
# or recreate for your teammates (or yourself later on).
config :mastani_server, MastaniServerWeb.Endpoint,
  secret_key_base: "efzPGFogKpgPlwFsjp/qBN7UMc40s5/HpOMNRLgi8hTzVuuqVL/36CmEbSLVHm+M"

# Configure your server database
config :mastani_server, MastaniServer.Repo,
  adapter: Ecto.Adapters.Postgres,
  username: "mastani_dba",
  password: "Mastanidba",
  database: "mastani_server_dev",
  hostname: "rm-uf6nh2z2c5907ex01.pg.rds.aliyuncs.com",
  port: 3433,
  pool_size: 15

config :mastani_server, :github_oauth,
  client_id: "3b4281c5e54ffd801f85",
  client_secret: "51f04dd8239b27f00a39a647ef3704de4c5ddc26"
