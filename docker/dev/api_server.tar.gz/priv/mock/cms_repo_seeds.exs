import MastaniServer.Factory

db_insert_multi(:repo, 5)
