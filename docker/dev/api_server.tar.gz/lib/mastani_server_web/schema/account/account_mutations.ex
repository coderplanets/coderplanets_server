defmodule MastaniServerWeb.Schema.Account.Mutations do
  @moduledoc """
  accounts mutations
  """
  use Helper.GqlSchemaSuite

  object :account_mutations do
    # @desc "hehehef: create a user"
    # field :create_user, :user do
    # arg(:username, non_null(:string))
    # arg(:nickname, non_null(:string))
    # arg(:bio, non_null(:string))
    # arg(:company, non_null(:string))

    # resolve(&R.Accounts.create_user/3)
    # end

    @desc "update user's profile"
    field :update_profile, :user do
      arg(:profile, non_null(:user_profile_input))

      middleware(M.Authorize, :login)
      resolve(&R.Accounts.update_profile/3)
    end

    field :github_signin, :token_info do
      arg(:code, non_null(:string))
      # arg(:profile, non_null(:github_profile_input))

      middleware(M.GithubUser)
      resolve(&R.Accounts.github_signin/3)
    end

    @doc "follow a user"
    field :follow, :user do
      arg(:user_id, non_null(:id))

      middleware(M.Authorize, :login)
      resolve(&R.Accounts.follow/3)
    end

    @doc "undo follow to a user"
    field :undo_follow, :user do
      arg(:user_id, non_null(:id))

      middleware(M.Authorize, :login)
      resolve(&R.Accounts.undo_follow/3)
    end

    @desc "mark a mention as read"
    field :mark_mention_read, :status do
      arg(:id, non_null(:id))

      middleware(M.Authorize, :login)
      resolve(&R.Accounts.mark_mention_read/3)
    end

    @desc "mark a all unread mention as read"
    field :mark_mention_read_all, :status do
      middleware(M.Authorize, :login)
      resolve(&R.Accounts.mark_mention_read_all/3)
    end

    @desc "mark a notification as read"
    field :mark_notification_read, :status do
      arg(:id, non_null(:id))

      middleware(M.Authorize, :login)
      resolve(&R.Accounts.mark_notification_read/3)
    end

    @desc "mark a all unread notifications as read"
    field :mark_notification_read_all, :status do
      middleware(M.Authorize, :login)
      resolve(&R.Accounts.mark_notification_read_all/3)
    end

    @desc "mark a system notification as read"
    field :mark_sys_notification_read, :status do
      arg(:id, non_null(:id))

      middleware(M.Authorize, :login)
      resolve(&R.Accounts.mark_sys_notification_read/3)
    end
  end
end
