defmodule GroupherServer.Logs do
  @moduledoc """
  The Logs context.
  """

  # import Ecto.Query, warn: false
  # alias GroupherServer.Repo

  # alias GroupherServer.Logs.UserActivity
end
