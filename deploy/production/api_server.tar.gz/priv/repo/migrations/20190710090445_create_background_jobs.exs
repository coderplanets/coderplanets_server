defmodule GroupherServer.Repo.Migrations.CreateBackgroundJobs do
  use Rihanna.Migration
end
