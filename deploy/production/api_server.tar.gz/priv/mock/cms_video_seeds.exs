import MastaniServer.Support.Factory

db_insert_multi(:video, 3)
