import GroupherServer.Support.Factory

db_insert_multi(:video, 3)
