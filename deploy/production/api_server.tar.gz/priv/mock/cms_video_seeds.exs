import MastaniServer.Factory

db_insert_multi(:video, 3)
