alias GroupherServer.CMS

# 1. place add community to GroupherServer.CMS.Delegate.SeedsConfig  first
# 2. need manulay set cate in categorify_communities

# CMS.seed_communities(:pl_patch)
CMS.seed_communities(:framework_patch)
