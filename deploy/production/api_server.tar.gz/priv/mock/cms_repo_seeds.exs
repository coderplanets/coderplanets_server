import MastaniServer.Support.Factory

db_insert_multi(:repo, 1)
