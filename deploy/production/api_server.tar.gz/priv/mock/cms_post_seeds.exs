# doc ..
import MastaniServer.Factory

db_insert(:post)
