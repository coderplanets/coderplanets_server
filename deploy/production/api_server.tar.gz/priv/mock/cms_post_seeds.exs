# doc ..
import MastaniServer.Support.Factory

db_insert(:post)
