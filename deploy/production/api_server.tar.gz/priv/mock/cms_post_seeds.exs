# doc ..
import GroupherServer.Support.Factory

db_insert(:post)
