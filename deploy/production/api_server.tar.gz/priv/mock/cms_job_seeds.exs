#

import MastaniServer.Factory

db_insert(:job)
