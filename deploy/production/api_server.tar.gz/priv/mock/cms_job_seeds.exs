#

import MastaniServer.Support.Factory

db_insert(:job)
