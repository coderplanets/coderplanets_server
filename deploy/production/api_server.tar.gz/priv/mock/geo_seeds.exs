import MastaniServer.Support.Factory

insert_geo_data()
