alias Helper.GeoPool

GeoPool.insert_geo_data()
