alias MastaniServer.CMS

# NOTE: the order is important
CMS.seed_communities(:pl)
CMS.seed_communities(:home)
